const CACHE_VERSION = 'bloxtory-v1';
const APP_SHELL_CACHE = `${CACHE_VERSION}-app-shell`;
const DYNAMIC_CACHE = `${CACHE_VERSION}-dynamic`;
const API_CACHE = `${CACHE_VERSION}-api`;

// Assets yang akan di-cache untuk offline (App Shell)
const APP_SHELL_ASSETS = [
  '/',
  '/index.html',
  '/app.bundle.js',
  '/images/logo.png',
  '/images/bloxtory_logo.png',
  '/favicon.png',
  '/manifest.json',
];

// ============================================
// INSTALL EVENT - Cache App Shell
// ============================================
self.addEventListener('install', (event) => {
  console.log('Service Worker: Installing...');
  event.waitUntil(
    caches.open(APP_SHELL_CACHE).then((cache) => {
      console.log('Service Worker: Caching App Shell');
      return cache.addAll(APP_SHELL_ASSETS).catch((error) => {
        console.error('Failed to cache:', error);
      });
    })
  );
  self.skipWaiting();
});

// ============================================
// ACTIVATE EVENT - Clean Old Caches
// ============================================
self.addEventListener('activate', (event) => {
  console.log('Service Worker: Activating...');
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName !== APP_SHELL_CACHE && 
              cacheName !== DYNAMIC_CACHE && 
              cacheName !== API_CACHE) {
            console.log('Service Worker: Deleting old cache:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
  self.clients.claim();
});

// ============================================
// FETCH EVENT - Advanced Caching Strategy
// ============================================
self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // 🔹 FILTER: Ignore non-http(s) requests (chrome-extension, devtools, etc)
  if (!request.url.startsWith('http')) {
    return;
  }

  // 🔹 FILTER: Ignore chrome extensions
  if (url.protocol === 'chrome-extension:') {
    return;
  }

  // 🔹 FILTER: Ignore requests with certain methods
  if (request.method !== 'GET') {
    return;
  }

  // Strategy 1: Cache First for App Shell & Static Assets
  if (APP_SHELL_ASSETS.includes(url.pathname) || 
      request.destination === 'style' || 
      request.destination === 'script' ||
      request.destination === 'image') {
    event.respondWith(cacheFirst(request, DYNAMIC_CACHE));
    return;
  }

  // Strategy 2: Network First for API Requests (Dynamic Content)
  if (url.origin === 'https://story-api.dicoding.dev') {
    event.respondWith(networkFirst(request, API_CACHE));
    return;
  }

  // Strategy 3: Stale While Revalidate for other requests
  event.respondWith(staleWhileRevalidate(request, DYNAMIC_CACHE));
});

// ============================================
// CACHING STRATEGIES
// ============================================

// Cache First - Untuk static assets
async function cacheFirst(request, cacheName) {
  try {
    const cache = await caches.open(cacheName);
    const cached = await cache.match(request);
    
    if (cached) {
      return cached;
    }

    const networkResponse = await fetch(request);
    
    // Only cache successful responses
    if (networkResponse && networkResponse.ok) {
      cache.put(request, networkResponse.clone());
    }
    
    return networkResponse;
  } catch (error) {
    console.error('Cache First error:', error);
    
    // Try to return cached version if available
    const cache = await caches.open(cacheName);
    const cached = await cache.match(request);
    
    if (cached) {
      return cached;
    }
    
    // Return offline response
    return new Response('Offline - Asset not available', { 
      status: 503,
      statusText: 'Service Unavailable'
    });
  }
}

// Network First - Untuk API data (prioritas data terbaru)
async function networkFirst(request, cacheName) {
  try {
    const cache = await caches.open(cacheName);
    const networkResponse = await fetch(request);
    
    if (networkResponse && networkResponse.ok) {
      // Simpan response terbaru ke cache
      cache.put(request, networkResponse.clone());
    }
    
    return networkResponse;
  } catch (error) {
    console.log('Network First fallback to cache:', error);
    
    // Jika network gagal, ambil dari cache
    const cache = await caches.open(cacheName);
    const cached = await cache.match(request);
    
    if (cached) {
      return cached;
    }

    // Fallback response jika tidak ada di cache
    return new Response(
      JSON.stringify({
        error: true,
        message: 'Offline - Data tidak tersedia'
      }),
      {
        status: 503,
        headers: { 'Content-Type': 'application/json' }
      }
    );
  }
}

// Stale While Revalidate - Untuk konten yang bisa agak lama
async function staleWhileRevalidate(request, cacheName) {
  try {
    const cache = await caches.open(cacheName);
    const cached = await cache.match(request);

    const fetchPromise = fetch(request).then((networkResponse) => {
      if (networkResponse && networkResponse.ok) {
        cache.put(request, networkResponse.clone());
      }
      return networkResponse;
    }).catch(() => cached);

    return cached || fetchPromise;
  } catch (error) {
    console.error('Stale While Revalidate error:', error);
    return new Response('Error loading resource', { status: 500 });
  }
}

// ============================================
// PUSH NOTIFICATION
// ============================================
self.addEventListener('push', (event) => {
  let data = {};

  try {
    const raw = event.data ? event.data.text() : '';
    if (raw instanceof Promise) {
      event.waitUntil(
        raw.then((resolved) => showParsedNotification(resolved))
      );
      return;
    } else {
      return event.waitUntil(showParsedNotification(raw));
    }
  } catch (err) {
    console.error('Error membaca data push:', err);
    data = { 
      title: 'Bloxtory Notification', 
      body: 'Ada cerita baru di Bloxtory!' 
    };
  }

  event.waitUntil(showNotification(data));
});

function showParsedNotification(raw) {
  let data = {};
  try {
    data = JSON.parse(raw);
  } catch {
    data = { 
      title: 'Bloxtory Notification', 
      body: raw || 'Ada cerita baru di Bloxtory!' 
    };
  }
  return showNotification(data);
}

function showNotification(data) {
  const title = data.title || 'Bloxtory Notification';
  const options = {
    body: data.body || 'Ada cerita baru di Bloxtory!',
    icon: data.icon || '/images/bloxtory_logo.png',
    badge: '/images/bloxtory_logo.png',
    data: { url: data.url || '#/home' },
    actions: [{ action: 'open_url', title: 'Lihat Detail' }],
  };
  return self.registration.showNotification(title, options);
}

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const urlToOpen = new URL(event.notification.data.url, self.location.origin).href;
  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
      for (const client of clientList) {
        if (client.url === urlToOpen && 'focus' in client) return client.focus();
      }
      if (clients.openWindow) return clients.openWindow(urlToOpen);
    })
  );
});