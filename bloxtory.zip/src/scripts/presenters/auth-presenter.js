import AuthApi from "../data/auth-api";

const TOKEN_KEY = "dicoding_token";
const USER_NAME_KEY = "dicoding_user_name";

class AuthPresenter {
  constructor({ mode = "login", formSelector, msgSelector } = {}) {
    this._mode = mode;
    this._form = document.querySelector(formSelector);
    this._msgEl = document.querySelector(msgSelector);

    // Spinner Overlay Global
    if (!document.querySelector(".global-spinner")) {
      const spinner = document.createElement("div");
      spinner.className = "global-spinner";
      spinner.innerHTML = `
        <div class="spinner-overlay">
          <div class="spinner-circle"></div>
        </div>
      `;
      document.body.appendChild(spinner);
    }
    this._spinner = document.querySelector(".global-spinner");

    if (this._form) {
      this._form.addEventListener("submit", (e) => this._onSubmit(e));
    }
  }

  async _onSubmit(event) {
    event.preventDefault();
    this._setMessage("Processing...", "info");
    this._toggleSpinner(true);

    try {
      const formData = new FormData(this._form);
      const payload = Object.fromEntries(formData.entries());

      if (this._mode === "register") {
        await AuthApi.register(payload);
        this._setMessage("Registration successful. Please login.", "success");

        setTimeout(() => {
          this._toggleSpinner(false);
          window.location.hash = "#/login";
        }, 900);
      } else {
        const data = await AuthApi.login(payload);
        const loginResult = data.loginResult || data;
        const token =
          loginResult.token || loginResult.accessToken || loginResult.authToken;
        const name = loginResult.name || loginResult.userId || "";

        if (!token) throw new Error("Token not found in login response");

        localStorage.setItem(TOKEN_KEY, token);
        localStorage.setItem(USER_NAME_KEY, name);

        this._setMessage("Login successful. Redirecting...", "success");
        this._updateNavbar();

        const redirectPage =
          sessionStorage.getItem("redirectAfterLogin") || "/home";
        sessionStorage.removeItem("redirectAfterLogin");

        setTimeout(() => {
          this._toggleSpinner(false);
          window.location.hash = `#${redirectPage}`;
        }, 800);
      }
    } catch (err) {
      console.error(err);
      this._setMessage(err.message || "Authentication failed", "error");
      this._toggleSpinner(false);
    } finally {
      this._toggleSpinner(false);
    }
  }

  _toggleSpinner(show) {
    if (this._spinner) {
      this._spinner.style.display = show ? "flex" : "none";
    }
  }

  _setMessage(text, type = "info") {
    if (!this._msgEl) return;
    this._msgEl.textContent = text;
    this._msgEl.setAttribute("aria-busy", type === "info");
    this._msgEl.className = `auth-msg ${type}`;
  }

  static logout() {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_NAME_KEY);
    AuthPresenter._updateNavbarStatic();
    window.location.hash = "#/home";
    location.reload();
  }

  _updateNavbar() {
    AuthPresenter._updateNavbarStatic();
  }

  static _updateNavbarStatic() {
    const token = localStorage.getItem(TOKEN_KEY);
    const navRight = document.querySelector(".nav-right");

    if (!navRight) return;

    if (token) {
      const name = localStorage.getItem(USER_NAME_KEY) || "User";
      navRight.innerHTML = `
        <span class="nav-user">Hi, ${escapeHtml(name)}</span>
        <button id="logoutBtn" class="btn-ghost">Logout</button>
      `;
      const logoutBtn = document.getElementById("logoutBtn");
      logoutBtn.addEventListener("click", () => AuthPresenter.logout());
    } else {
      navRight.innerHTML = `
        <a href="#/login">Login</a>
        <a href="#/register">Register</a>
      `;
    }
  }

  static isLoggedIn() {
    return !!localStorage.getItem(TOKEN_KEY);
  }
}

function escapeHtml(str) {
  return String(str)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

export default AuthPresenter;
