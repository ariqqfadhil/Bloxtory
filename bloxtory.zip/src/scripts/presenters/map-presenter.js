import StoryApi from "../data/api";
import LeafletConfig from "../utils/leaflet-config";
import L from "leaflet";

class MapPresenter {
  constructor() {
    this._map = LeafletConfig.initMap();
    this._storyListContainer = document.querySelector("#storyList");
    this._markers = [];
    this._activeMarker = null;
    this._activeCard = null;

    this._renderStories();
  }

  async _renderStories() {
    try {
      const stories = await StoryApi.getStories({ location: 1 });

      // Ambil parameter dari URL
      const hash = window.location.hash;
      const params = new URLSearchParams(hash.split("?")[1]);
      const latParam = parseFloat(params.get("lat"));
      const lonParam = parseFloat(params.get("lon"));

      // Render daftar cerita
      this._storyListContainer.innerHTML = stories
        .map(
          (story, index) => `
          <article
            class="story-card"
            role="button"
            tabindex="0"
            data-index="${index}"
            data-lat="${story.lat}"
            data-lon="${story.lon}">
            <img
              src="${story.photoUrl}"
              alt="Story Photo Location: ${story.name}" />
            <div class="story-content">
              <h2>${story.name}</h2>
              <p class="story-desc">${story.description}</p>
              <small class="story-date">
                ${new Date(story.createdAt)
                  .toLocaleString("id-ID", {
                    day: "2-digit",
                    month: "long",
                    year: "numeric",
                    hour: "2-digit",
                    minute: "2-digit",
                  })
                  .replace("pukul", ",")
                  .replace(/\s+,/, ",")}
              </small>
            </div>
          </article>
        `,
        )
        .join("");

      // Tambahkan marker ke peta
      stories.forEach((story, index) => {
        if (!story.lat || !story.lon) return;

        const marker = L.marker([story.lat, story.lon]).addTo(this._map);
        marker.bindPopup(
          `<strong>${story.name}</strong><br>${story.description}`,
        );
        marker._storyIndex = index;

        // Klik marker -> highlight card di list
        marker.on("click", () => this._highlightStory(index));

        this._markers.push(marker);
      });

      // Jika ada koordinat dari URL → pindah ke sana dan highlight
      if (!isNaN(latParam) && !isNaN(lonParam)) {
        this._map.setView([latParam, lonParam], 10);

        // Cari marker terdekat dengan lat/lon dari URL
        const foundIndex = stories.findIndex(
          (story) =>
            story.lat &&
            story.lon &&
            Math.abs(story.lat - latParam) < 0.0001 &&
            Math.abs(story.lon - lonParam) < 0.0001,
        );

        if (foundIndex !== -1) {
          this._highlightStory(foundIndex);
          const marker = this._markers[foundIndex];
          if (marker) marker.openPopup();
        }
      }

      // Klik card -> fokus ke marker
      this._storyListContainer.addEventListener("click", (event) => {
        const card = event.target.closest(".story-card");
        if (!card) return;

        const index = parseInt(card.dataset.index);
        this._highlightStory(index);

        const marker = this._markers[index];
        if (marker) {
          this._map.setView(marker.getLatLng(), 10);
          marker.openPopup();
        }
      });
    } catch (error) {
      console.error(error);
      this._storyListContainer.innerHTML = `
        <p class="error">Failed to load stories. Please try again later.</p>
      `;
    }
  }

  _highlightStory(index) {
    // Reset marker sebelumnya
    if (this._activeMarker) {
      this._activeMarker.setIcon(new L.Icon.Default());
    }

    // Reset list aktif sebelumnya
    if (this._activeCard) {
      this._activeCard.classList.remove("active");
    }

    // Set marker baru jadi aktif
    const marker = this._markers[index];
    if (marker) {
      const activeIcon = L.icon({
        iconUrl: "https://cdn-icons-png.flaticon.com/512/535/535239.png",
        iconSize: [38, 38],
        iconAnchor: [19, 38],
        popupAnchor: [0, -38],
      });
      marker.setIcon(activeIcon);
      this._activeMarker = marker;
    }

    // Highlight card aktif
    const card = this._storyListContainer.querySelector(
      `.story-card[data-index="${index}"]`,
    );
    if (card) {
      card.classList.add("active");
      this._activeCard = card;

      // Auto-scroll ke card aktif (smooth)
      card.scrollIntoView({
        behavior: "smooth",
        block: "center",
      });
    }
  }
}

export default MapPresenter;
