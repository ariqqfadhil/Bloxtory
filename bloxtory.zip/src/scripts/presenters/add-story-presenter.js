import StoryApi from "../data/api";

class AddStoryPresenter {
  constructor({ form, cameraElements }) {
    this._form = form;
    this._camera = cameraElements;
    this._stream = null;
    this._photoFile = null;

    this._camera.preview = document.querySelector("#photoPreview");
    this._camera.closeBtn = document.querySelector("#closeCameraBtn");
    this._photoSource = document.querySelector("#photoSource");
    this._photoActions = document.querySelector("#photoActions");
    this._removeBtn = document.querySelector("#removePhotoBtn");
    this._retakeBtn = document.querySelector("#retakePhotoBtn");

    this._initCameraFeature();
    this._initPhotoActions();

    this._form.addEventListener("submit", (e) => this._onSubmit(e));
  }

  _initCameraFeature() {
    const { openBtn, video, captureBtn, canvas, photoInput } = this._camera;

    if (
      !navigator.mediaDevices ||
      typeof navigator.mediaDevices.getUserMedia !== "function"
    ) {
      console.warn("The camera is not available in this environment.");
      openBtn.disabled = true;
      openBtn.textContent = "Camera not supported";
      return;
    }

    openBtn.addEventListener("click", async () => {
      try {
        openBtn.disabled = true;
        openBtn.textContent = "Activating camera...";

        this._stream = await navigator.mediaDevices.getUserMedia({
          video: true,
        });
        video.style.display = "block";
        captureBtn.style.display = "inline-block";
        video.srcObject = this._stream;

        openBtn.textContent = "Camera Active";
        this._camera.closeBtn.style.display = "inline-block";
      } catch (err) {
        alert(
          "Unable to access the camera. Ensure permissions are granted in the browser.",
        );
        console.error("getUserMedia error:", err);
        openBtn.disabled = false;
        openBtn.textContent = "Take from Camera";
      }
    });

    this._camera.closeBtn.addEventListener("click", () => {
      this._stopCamera();
      this._camera.closeBtn.style.display = "none";
      openBtn.disabled = false;
      openBtn.textContent = "Take from Camera";
      alert("Camera has been turned off.");
    });

    captureBtn.addEventListener("click", () => {
      try {
        const context = canvas.getContext("2d");
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        context.drawImage(video, 0, 0, canvas.width, canvas.height);

        canvas.toBlob((blob) => {
          if (!blob) {
            alert("Failed to take a photo from the camera.");
            return;
          }

          this._photoFile = new File([blob], "camera-photo.jpg", {
            type: "image/jpeg",
          });
          const preview = this._camera.preview;
          const imageUrl = URL.createObjectURL(blob);

          preview.src = imageUrl;
          preview.style.display = "block";
          document.querySelector("#photoPreviewWrapper").style.display =
            "block";
          this._photoSource.textContent = "Image taken from camera";

          this._camera.photoInput.removeAttribute("required");

          this._photoActions.style.display = "block";
          this._removeBtn.style.display = "inline-block";
          this._retakeBtn.style.display = "inline-block";

          alert("✅ The photo was successfully taken from the camera!");
          this._stopCamera();
        });
      } catch (err) {
        console.error("Error saat menangkap foto:", err);
        alert("An error occurred while taking the photo.");
      }
    });

    photoInput.addEventListener("change", () => {
      if (photoInput.files.length > 0) {
        this._camera.preview.src = URL.createObjectURL(photoInput.files[0]);
        this._camera.preview.style.display = "block";
        document.querySelector("#photoPreviewWrapper").style.display = "block";
        this._photoSource.textContent = "Image selected from uploaded file.";
        this._photoActions.style.display = "block";
        this._removeBtn.style.display = "inline-block";
        this._retakeBtn.style.display = "none";
      }

      if (this._stream) this._stopCamera();
    });
  }

  _initPhotoActions() {
    // Hapus gambar yang dipilih
    this._removeBtn.addEventListener("click", () => {
      document.querySelector("#photoPreviewWrapper").style.display = "none";
      this._photoFile = null;
      this._camera.photoInput.value = "";
      this._camera.preview.style.display = "none";
      this._photoSource.textContent = "";
      this._photoActions.style.display = "none";

      // Re-enable camera button
      this._camera.openBtn.disabled = false;
      this._camera.openBtn.textContent = "Take from Camera";
      alert("Image deleted. Please select or take a new photo.");
    });

    // Retake foto dari kamera
    this._retakeBtn.addEventListener("click", async () => {
      this._photoFile = null;
      this._camera.preview.style.display = "none";
      this._photoSource.textContent = "";
      this._photoActions.style.display = "none";
      await this._restartCamera();
    });
  }

  async _restartCamera() {
    const { openBtn, video, captureBtn } = this._camera;

    try {
      this._stream = await navigator.mediaDevices.getUserMedia({ video: true });
      video.style.display = "block";
      captureBtn.style.display = "inline-block";
      video.srcObject = this._stream;
      openBtn.textContent = "Camera Active (retake)";
    } catch (err) {
      alert("Unable to access the camera again.");
      console.error(err);
    }
  }

  _stopCamera() {
    if (this._stream) {
      this._stream.getTracks().forEach((track) => track.stop());
      this._stream = null;
    }

    this._camera.video.style.display = "none";
    this._camera.captureBtn.style.display = "none";
    this._camera.closeBtn.style.display = "none";
  }

  async _onSubmit(e) {
    e.preventDefault();

    const description = this._form.querySelector("#description").value.trim();
    const photo =
      this._photoFile || this._form.querySelector("#photo").files[0];
    const lat = this._form.querySelector("#lat").value;
    const lon = this._form.querySelector("#lon").value;

    if (!description || !photo) {
      alert("Description and photo are required. Location is optional.");
      return;
    }

    try {
      await StoryApi.addStory({ description, photo, lat, lon });
      alert("✅ Story successfully added!");
      this._form.reset();
      this._photoFile = null;
      this._camera.preview.style.display = "none";
      this._photoSource.textContent = "";
      this._photoActions.style.display = "none";
      this._stopCamera();
      window.location.hash = "/map";
    } catch (error) {
      console.error("Error when adding a story:", error);
      alert("Failed to add story. Please try again.");
    } finally {
      this._stopCamera();
    }
  }
}

export default AddStoryPresenter;
