import StoryApi from "../data/api";

class HomePresenter {
  constructor(container) {
    this._container = container;
    this._renderStories();
  }

  async _renderStories() {
    this._container.classList.add("fade-out");
    this._container.innerHTML = `<p class="loading">Loading Stories from server...</p>`;

    try {
      const stories = await StoryApi.getStories({ location: 1 });

      if (!stories.length) {
        this._container.innerHTML = `
          <p class="empty">Unable to display timeline, please <a href="#/login">login</a> first</p>
        `;
        this._container.classList.remove("fade-out");
        this._container.classList.add("fade-in");
        return;
      }

      const html = stories
        .map(
          (story) => `
          <article class="story-card">
            <img src="${story.photoUrl}" alt="Photo by ${story.name}" class="story-photo" />
            <div class="story-content">
              <h2>${story.name}</h2>
              <p class="story-desc">${story.description}</p>
              <small class="story-date">
                ${new Date(story.createdAt)
                  .toLocaleString("id-ID", {
                    day: "2-digit",
                    month: "long",
                    year: "numeric",
                    hour: "2-digit",
                    minute: "2-digit",
                  })
                  .replace("pukul", ",")
                  .replace(/\s+,/, ",")}
              </small>
              ${
                story.lat && story.lon
                  ? `<button
                      class="view-on-map-btn"
                      data-lat="${story.lat}"
                      data-lon="${story.lon}">
                      📍 See on the Map
                    </button>`
                  : ""
              }
            </div>
          </article>
        `,
        )
        .join("");

      // Tampilkan hasil dengan animasi fade-in
      this._container.innerHTML = html;
      this._applyFadeIn();

      // Event: Klik tombol "See on the Map"
      this._container.addEventListener("click", (event) => {
        const btn = event.target.closest(".view-on-map-btn");
        if (!btn) return;

        const lat = btn.dataset.lat;
        const lon = btn.dataset.lon;

        window.location.hash = `#/map?lat=${lat}&lon=${lon}`;
      });

      // Event: Klik "Lihat di Map"
      this._container.addEventListener("click", (event) => {
        const btn = event.target.closest(".view-on-map-btn");
        if (!btn) return;

        const lat = btn.dataset.lat;
        const lon = btn.dataset.lon;

        // Simpan ke URL hash agar MapPage bisa baca
        window.location.hash = `#/map?lat=${lat}&lon=${lon}`;
      });

      // Event: Klik gambar untuk tampil besar
      this._container.addEventListener("click", (event) => {
        const img = event.target.closest(".story-photo");
        if (!img) return;

        const overlay = document.createElement("div");
        overlay.classList.add("image-overlay");
        overlay.innerHTML = `
        <div class="overlay-content">
          <img src="${img.src}" alt="${img.alt}" class="overlay-image" />
          <button class="overlay-close" aria-label="Close image">✕</button>
        </div>
      `;
        document.body.appendChild(overlay);

        // Tutup saat klik tombol atau luar gambar
        overlay.addEventListener("click", (e) => {
          if (
            e.target.classList.contains("overlay-close") ||
            e.target === overlay
          ) {
            overlay.classList.add("fade-out");
            setTimeout(() => overlay.remove(), 300);
          }
        });
      });
    } catch (error) {
      console.error(error);
      this._container.innerHTML = `
        <p class="error">An error occurred while loading the story. Please try again later.</p>
      `;
      this._applyFadeIn();
    }
  }

  _applyFadeIn() {
    this._container.classList.remove("fade-out");
    this._container.classList.add("fade-in");
    setTimeout(() => this._container.classList.remove("fade-in"), 400);
  }
}

export default HomePresenter;
