import "../styles/styles.css";
import App from "./app";
import AuthPresenter from "./presenters/auth-presenter";

const app = App;

window.addEventListener("hashchange", () => {
  app.renderPage();
});

window.addEventListener("load", () => {
  AuthPresenter._updateNavbarStatic();
  app.renderPage();
});
