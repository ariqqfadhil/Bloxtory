import HomePresenter from "../../presenters/home-presenter";

const USER_TOKEN_KEY = "dicoding_token";

const HomePage = {
  async render() {
    return `
      <section class="page fade" id="homePage">
        <div class="home-hero">
          <h1 class="visually-hidden">Bloxtory — Share Your Stories and Inspiration</h1>
          <img
            src="/images/bloxtory_logo.png"
            alt="Logo Bloxtory"
            class="home-logo"
          />
        </div>
        
        <div class="home-actions">
          <button id="addStoryBtn" aria-label="Tambah cerita baru">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="18"
              height="18"
              fill="white"
              viewBox="0 0 24 24"
              class="plus-icon"
            >
              <path d="M12 5v14m-7-7h14" stroke="white" stroke-width="2" stroke-linecap="round"/>
            </svg>
            Add New Story
          </button>
        </div>

        <div id="storyList" class="story-list" aria-live="polite">
          <p class="loading">Loading Stories...</p>
        </div>
      </section>
    `;
  },

  async afterRender() {
    const addStoryBtn = document.querySelector("#addStoryBtn");

    addStoryBtn.addEventListener("click", () => {
      const token = localStorage.getItem(USER_TOKEN_KEY);

      if (!token) {
        alert("Please log in first to add or view stories.");
        window.location.hash = "#/login";
        return;
      }

      window.location.hash = "#/add-story";
    });

    new HomePresenter(document.querySelector("#storyList"));
  },
};

export default HomePage;
