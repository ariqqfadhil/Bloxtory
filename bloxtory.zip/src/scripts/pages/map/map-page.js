import MapPresenter from "../../presenters/map-presenter";

const MapPage = {
  async render() {
    return `
      <section class="page fade" aria-labelledby="storyMapTitle">
        <h1 id="storyMapTitle">User Map Stories</h1>

        <div class="map-container">
          <!-- Area peta interaktif -->
          <div
            id="map"
            role="region"
            aria-label="Story Map Location"
            tabindex="0">
          </div>

          <!-- Daftar cerita -->
          <div class="map-story-list">
            <h2 id="storyListTitle">Stories With Location</h2>
            <section
              id="storyList"
              class="story-list"
              aria-labelledby="storyListTitle"
              aria-live="polite">
              <p class="loading">Loading Stories from server...</p>
            </section>
          </div>
        </div>
      </section>
    `;
  },

  async afterRender() {
    new MapPresenter();
  },
};

export default MapPage;
