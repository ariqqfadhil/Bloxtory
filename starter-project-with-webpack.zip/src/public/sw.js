self.addEventListener('push', (event) => {
  let data = {};

  try {
    // Coba ambil teks mentah
    const raw = event.data ? event.data.text() : '';
    if (raw instanceof Promise) {
      // Jika text() mengembalikan Promise (browser modern)
      event.waitUntil(
        raw.then((resolved) => showParsedNotification(resolved))
      );
      return;
    } else {
      // Browser lama
      return event.waitUntil(showParsedNotification(raw));
    }
  } catch (err) {
    console.error('Error membaca data push:', err);
    data = { title: 'Bloxtory Notification', body: 'Ada cerita baru di Bloxtory!' };
  }

  event.waitUntil(showNotification(data));
});

function showParsedNotification(raw) {
  let data = {};
  try {
    data = JSON.parse(raw);
  } catch {
    data = { title: 'Bloxtory Notification', body: raw || 'Ada cerita baru di Bloxtory!' };
  }
  return showNotification(data);
}

function showNotification(data) {
  const title = data.title || 'Bloxtory Notification';
  const options = {
    body: data.body || 'Ada cerita baru di Bloxtory!',
    icon: data.icon || '/images/logo.png',
    badge: '/images/logo.png',
    data: { url: data.url || '#/home' },
    actions: [{ action: 'open_url', title: 'Lihat Detail' }],
  };
  return self.registration.showNotification(title, options);
}

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const urlToOpen = new URL(event.notification.data.url, self.location.origin).href;
  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
      for (const client of clientList) {
        if (client.url === urlToOpen && 'focus' in client) return client.focus();
      }
      if (clients.openWindow) return clients.openWindow(urlToOpen);
    })
  );
});
