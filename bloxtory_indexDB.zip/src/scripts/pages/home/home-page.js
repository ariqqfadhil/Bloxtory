import HomePresenter from "../../presenters/home-presenter";
import StoryApi from "../../data/api";

const USER_TOKEN_KEY = "dicoding_token";

const HomePage = {
  async render() {
    return `
      <section class="page fade" id="homePage">
        <div class="home-hero">
          <h1 class="visually-hidden">Bloxtory — Share Your Stories and Inspiration</h1>
          <img
            src="/images/bloxtory_logo.png"
            alt="Logo Bloxtory"
            class="home-logo"
          />
        </div>
        
        <div class="home-actions">
          <button id="addStoryBtn" aria-label="Tambah cerita baru">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="18"
              height="18"
              fill="white"
              viewBox="0 0 24 24"
              class="plus-icon"
            >
              <path d="M12 5v14m-7-7h14" stroke="white" stroke-width="2" stroke-linecap="round"/>
            </svg>
            Add New Story
          </button>
        </div>

        <div id="storyList" class="story-list" aria-live="polite">
          <p class="loading">Loading Stories...</p>
        </div>
      </section>
    `;
  },

  async afterRender() {
    const listContainer = document.querySelector("#storyList");
    const addStoryBtn = document.querySelector("#addStoryBtn");

    // ========== View Layer ==========
    const view = {
      showLoading() {
        listContainer.classList.add("fade-out");
        listContainer.innerHTML = `<p class="loading">Loading Stories from server...</p>`;
      },

      showError(message) {
        listContainer.innerHTML = `<p class="error">${message}</p>`;
        this.applyFadeIn();
      },

      renderStories(stories) {
        if (!stories.length) {
          listContainer.innerHTML = `
            <p class="empty">Unable to display timeline, please <a href="#/login">login</a> first</p>
          `;
          this.applyFadeIn();
          return;
        }

        const html = stories
          .map(
            (story) => `
          <article class="story-card">
            <img src="${story.photoUrl}" alt="Photo by ${story.name}" class="story-photo" />
            <div class="story-content">
              <h2>${story.name}</h2>
              <p class="story-desc">${story.description}</p>
              <small class="story-date">
                ${new Date(story.createdAt)
                  .toLocaleString("id-ID", {
                    day: "2-digit",
                    month: "long",
                    year: "numeric",
                    hour: "2-digit",
                    minute: "2-digit",
                  })
                  .replace("pukul", ",")
                  .replace(/\s+,/, ",")}
              </small>
              ${
                story.lat && story.lon
                  ? `<button
                      class="view-on-map-btn"
                      data-lat="${story.lat}"
                      data-lon="${story.lon}">
                      📍 See on the Map
                    </button>`
                  : ""
              }
            </div>
          </article>
        `,
          )
          .join("");

        listContainer.innerHTML = html;
        this.applyFadeIn();
      },

      onStoryClick(handler) {
        listContainer.addEventListener("click", handler);
      },

      applyFadeIn() {
        listContainer.classList.remove("fade-out");
        listContainer.classList.add("fade-in");
        setTimeout(() => listContainer.classList.remove("fade-in"), 400);
      },

      showImageOverlay(imgSrc, altText) {
        const overlay = document.createElement("div");
        overlay.classList.add("image-overlay");
        overlay.innerHTML = `
          <div class="overlay-content">
            <img src="${imgSrc}" alt="${altText}" class="overlay-image" />
            <button class="overlay-close" aria-label="Close image">✕</button>
          </div>
        `;
        document.body.appendChild(overlay);

        overlay.addEventListener("click", (e) => {
          if (
            e.target.classList.contains("overlay-close") ||
            e.target === overlay
          ) {
            overlay.classList.add("fade-out");
            setTimeout(() => overlay.remove(), 300);
          }
        });
      },
    };

    // ========== Tombol Add Story ==========
    addStoryBtn.addEventListener("click", () => {
      const token = localStorage.getItem(USER_TOKEN_KEY);
      if (!token) {
        alert("Please log in first to add or view stories.");
        window.location.hash = "#/login";
        return;
      }
      window.location.hash = "#/add-story";
    });

    // ========== Inisialisasi Presenter ==========
    new HomePresenter({ view, model: StoryApi });
  },
};

export default HomePage;
