import StoryApi from "../data/api";

class HomePresenter {
  constructor({ view, model = StoryApi }) {
    this.view = view;
    this.model = model;

    this._init();
  }

  async _init() {
    this.view.showLoading();

    try {
      const stories = await this.model.getStories({ location: 1 });
      this.view.renderStories(stories);

      // Event listener tunggal diatur di sini
      this.view.onStoryClick((event) => {
        const mapBtn = event.target.closest(".view-on-map-btn");
        const img = event.target.closest(".story-photo");

        if (mapBtn) {
          const lat = mapBtn.dataset.lat;
          const lon = mapBtn.dataset.lon;
          window.location.hash = `#/map?lat=${lat}&lon=${lon}`;
          return;
        }

        if (img) {
          this.view.showImageOverlay(img.src, img.alt);
        }
      });
    } catch (error) {
      console.error(error);
      this.view.showError(
        "An error occurred while loading the story. Please try again later.",
      );
    }
  }
}

export default HomePresenter;
