import "../styles/styles.css";
import App from "./app";
import AuthPresenter from "./presenters/auth-presenter";
import ServiceWorkerRegister from "./utils/service-worker-register";
import NotificationHelper from "./utils/notification-helper";

const app = App;

document.addEventListener("DOMContentLoaded", () => {
  console.log("🚀 Bloxtory App Starting...");

  // Register Service Worker
  ServiceWorkerRegister.register();

  // Initialize your app
  // App.init();

  console.log("✅ App Initialized");
});

// Render ulang halaman saat hash berubah
window.addEventListener("hashchange", () => {
  app.renderPage();
});

window.addEventListener("load", async () => {
  AuthPresenter._updateNavbarStatic();
  app.renderPage();

  // === SETUP PUSH NOTIFICATION ===
  const registration = await ServiceWorkerRegister.register();
  if (!registration) return;

  // Pastikan tombol toggle ada di DOM
  const pushToggle = document.getElementById("pushToggle");
  if (!pushToggle) {
    console.warn("Push toggle button tidak ditemukan di DOM.");
    return;
  }

  // Cek permission
  const permission = Notification.permission;
  if (permission === "denied") {
    pushToggle.disabled = true;
    pushToggle.textContent = "🚫 Notifications blocked";
    return;
  }

  // Perbarui status awal tombol berdasarkan subscription user
  const currentSub = await registration.pushManager.getSubscription();
  updateToggleButton(pushToggle, !!currentSub);

  // === Event klik tombol toggle ===
  pushToggle.addEventListener("click", async () => {
    const subscription = await registration.pushManager.getSubscription();

    if (subscription) {
      // Jika sudah langganan → lakukan unsubscribe ke server dan browser
      await NotificationHelper.unsubscribeUserFromPush(registration);
      updateToggleButton(pushToggle, false);
    } else {
      // Jika belum langganan → minta izin dan subscribe
      const permissionGranted = await NotificationHelper.requestPermission();
      if (!permissionGranted) {
        console.warn("User menolak izin notifikasi.");
        return;
      }

      await NotificationHelper.subscribeUserToPush(registration);
      updateToggleButton(pushToggle, true);
    }
  });

  console.log("Push Notification siap digunakan 🚀");
});

/**
 * Fungsi pembantu untuk memperbarui tampilan tombol
 */
function updateToggleButton(button, isSubscribed) {
  if (isSubscribed) {
    button.textContent = "🔔 Notification: ON";
    button.setAttribute("aria-pressed", "true");
  } else {
    button.textContent = "🔕 Notification: OFF";
    button.setAttribute("aria-pressed", "false");
  }
}
